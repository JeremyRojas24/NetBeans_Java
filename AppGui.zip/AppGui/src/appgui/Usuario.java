/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appgui;

/**
 *
 * @author jrrm
 */
public class Usuario {
    private String name;
    private String email;
    private String mobileNumber;
    private String photo;
    private String password;
    
    //Constructor 
    public Usuario (String name, String email, String mobileNumber, String photo, String password)
    {
        this.name = name;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.photo = photo;
        this.password = password;
    }
    
    //Métodos get
    public String getName ()
    {
            return this.name;
    }
    
    public String getEmail ()
    {
        return this.email;
    }
    
    public String getMobileNumber ()
    {
        return this.mobileNumber;
    }
    
    public String getPhoto ()
    {
        return this.photo;
    }
    
    public String getPassword ()
    {
        return this.password;
    }
    
    //Métodos set
    public void setName (String name)
    {
        this.name = name;
    }
    
    public void setEmail (String email)
    {
        this.email = email;
    }
    
    public void setMobileNumber (String mobileNumber)
    {
        this.mobileNumber = mobileNumber;
    }
    
    public void setPhoto (String Photo)
    {
        this.photo = Photo;
    }
    
    public void setPassword (String Password)
    {
        this.password = password;
    }
    
    //Métodos auxiliares
    public String getData()
    {
        String data = "\nUSER DATA\n";
        data = data.concat("\nName            : " + this.name);
        data = data.concat("\ne-Mail           : " + this.email);
        data = data.concat("\nMobile Number : " + this.mobileNumber);
        data = data.concat("\nPhoto            : " + this.photo);
        data = data.concat("\nPassword      : " + this.password);
        
        return data;
    }
    
}
