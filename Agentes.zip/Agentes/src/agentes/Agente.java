/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agentes;

import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Luis Castillo ft Antonio Aguilar, documentacion y produccion Jeremy
 * Mendoza
 */
public class Agente extends Thread {

    String nombre;
    int i;
    int j;
    ImageIcon icon;
    int[][] matrix;
    JLabel tablero[][];
    ImageIcon obstaculo;
    Escenario e;
    boolean carryingSamples = false;
    boolean naveDet = false;
    JLabel casillaAnterior;
    Random aleatorio = new Random(System.currentTimeMillis());
    ImageIcon nave;
    int naveI;
    int naveJ;
    int contadorBloqueado = 0;
    boolean bloqueado = false;
    int contador = 0;

    public Agente(String nombre, ImageIcon icon, int[][] matrix, JLabel tablero[][], Escenario e, ImageIcon nave) {
        this.nombre = nombre;
        this.icon = icon;
        this.matrix = matrix;
        this.tablero = tablero;
        this.e = e;
        this.i = aleatorio.nextInt(matrix.length);
        this.j = aleatorio.nextInt(matrix.length);
        tablero[i][j].setIcon(icon);
        this.nave = nave;
    }

    private void setNave() {
        int x, y;

        for (x = 0; x < e.dim; x++) {
            for (y = 0; y < e.dim; y++) {
                if (tablero[x][y].getIcon() == nave) {
                    naveI = x;
                    naveJ = y;
                    return;
                }
            }
        }
    }

    public void run() {
        e.cuentaSamples();
        setNave();
        
        while (e.contadorSamples>0) {
            System.out.println("conta: "+e.contadorSamples);
            casillaAnterior = tablero[i][j];

            while (!carryingSamples) {

                int movimientoRandom = aleatorio.nextInt(4);

                if (movimientoRandom == 0) {
                    if (!e.detectaObstaculo(i + 1, j, carryingSamples)) {
                        if (i > matrix.length - 2) {
                            i = 0;
                            actualizarPosicion();
                        } else {
                            i++;
                            actualizarPosicion();
                        }
                        break;
                    } else {
                        continue;
                    }
                }

                if (movimientoRandom == 1) {
                    if (!e.detectaObstaculo(i - 1, j, carryingSamples)) {
                        if (i < 1) {
                            i = matrix.length - 1;
                            actualizarPosicion();
                        } else {
                            i--;
                            actualizarPosicion();
                        }
                        break;
                    } else {
                        continue;
                    }
                }

                if (movimientoRandom == 2) {
                    if (!e.detectaObstaculo(i, j + 1, carryingSamples)) {
                        if (j > matrix.length - 2) {
                            j = 0;
                            actualizarPosicion();
                        } else {
                            j++;
                            actualizarPosicion();
                        }
                        break;
                    } else {
                        continue;
                    }
                }

                if (movimientoRandom == 3) {
                    if (!e.detectaObstaculo(i, j - 1, carryingSamples)) {
                        if (j < 1) {
                            j = matrix.length - 1;
                            actualizarPosicion();
                        } else {
                            j--;
                            actualizarPosicion();
                        }
                        break;
                    } else {
                        continue;
                    }
                }
            }

            while (carryingSamples) {
                
                contadorBloqueado++;
                casillaAnterior = tablero[i][j];
                int gradientI = naveI - i;
                int gradientJ = naveJ - j;
                //System.out.println("gradienteI: "+gradientI);
                int movimientoRandom = aleatorio.nextInt(4);

                if (movimientoRandom == 0) {
                    if (!e.detectaObstaculo(i + 1, j, carryingSamples)) {
                        if (gradientI > 0) {
                            if (i > matrix.length - 2) {
                                i = 0;
                                actualizarPosicion();
                            } else {
                                i++;
                                actualizarPosicion();
                            }

                            break;
                        }
                    }
                }

                if (movimientoRandom == 1) {
                    if (!e.detectaObstaculo(i - 1, j, carryingSamples)) {
                        if (gradientI < 0) {
                            if (i < 1) {
                                i = matrix.length - 1;
                                actualizarPosicion();
                            } else {
                                i--;
                                actualizarPosicion();
                            }

                            break;
                        }
                    }
                }

                if (movimientoRandom == 2) {
                    if (!e.detectaObstaculo(i, j + 1, carryingSamples)) {
                        if (gradientJ > 0) {
                            if (j > matrix.length - 2) {
                                j = 0;
                                actualizarPosicion();
                            } else {
                                j++;
                                actualizarPosicion();
                            }

                            break;
                        }
                    }
                }

                if (movimientoRandom == 3) {
                    if (!e.detectaObstaculo(i, j - 1, carryingSamples)) {
                        if (gradientJ < 0) {
                            if (j < 1) {
                                j = matrix.length - 1;
                                actualizarPosicion();
                            } else {
                                j--;
                                actualizarPosicion();
                            }

                            break;
                        }
                    }
                }

                if (contadorBloqueado>100) {
                    if (movimientoRandom == 0) {
                        if (!e.detectaObstaculo(i + 1, j, carryingSamples)) {
                            if (i > matrix.length - 2) {
                                i = 0;
                                actualizarPosicion();
                            } else {
                                i++;
                                actualizarPosicion();
                            }
                            break;
                        } else {
                            continue;
                        }
                    }

                    if (movimientoRandom == 1) {
                        if (!e.detectaObstaculo(i - 1, j, carryingSamples)) {
                            if (i < 1) {
                                i = matrix.length - 1;
                                actualizarPosicion();
                            } else {
                                i--;
                                actualizarPosicion();
                            }
                            break;
                        } else {
                            continue;
                        }
                    }

                    if (movimientoRandom == 2) {
                        if (!e.detectaObstaculo(i, j + 1, carryingSamples)) {
                            if (j > matrix.length - 2) {
                                j = 0;
                                actualizarPosicion();
                            } else {
                                j++;
                                actualizarPosicion();
                            }
                            break;
                        } else {
                            continue;
                        }
                    }

                    if (movimientoRandom == 3) {
                        if (!e.detectaObstaculo(i, j - 1, carryingSamples)) {
                            if (j < 1) {
                                j = matrix.length - 1;
                                actualizarPosicion();
                            } else {
                                j--;
                                actualizarPosicion();
                            }
                            break;
                        } else {
                            continue;
                        }
                    }
                }
            }

            try {
                sleep(350);   // nextInt me da un numero aleatorio entre 1 y 99
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    public void actualizarPosicion() {

        bloqueado = false;
        if (e.detectarSample(i, j) && carryingSamples == false) {
            carryingSamples = true;
            contador++;
        }

        if (e.detectarNave(i + 1, j, carryingSamples) && carryingSamples == true) {
            carryingSamples = false;
        } else if (e.detectarNave(i - 1, j, carryingSamples) && carryingSamples == true) {
            carryingSamples = false;
        } else if (e.detectarNave(i, j + 1, carryingSamples) && carryingSamples == true) {
            carryingSamples = false;
        } else if (e.detectarNave(i, j - 1, carryingSamples) && carryingSamples == true) {
            carryingSamples = false;
        }

        casillaAnterior.setIcon(null); // Elimina su figura de la casilla anterior
        tablero[i][j].setIcon(icon); // Pone su figura en la nueva casilla
        contadorBloqueado = contadorBloqueado - 50;
    }
    
    public void resetContador() {
        contador = 0;
    }
    
    public double getContador() {
        return contador;
    }

}

