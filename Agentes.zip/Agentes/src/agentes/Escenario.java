/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agentes;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextField;

/**
 *
 * @author macario
 */
public class Escenario extends JFrame
{
    
    private JLabel[][] tablero;     
    private int[][] matrix;
    public final int dim = 10;
    public int contadorSamples = 0;
    public int contador = 0;
    private ImageIcon robot1;
    private ImageIcon robot2;
    private ImageIcon obstacleIcon;
    private ImageIcon sampleIcon;
    private ImageIcon actualIcon;
    private ImageIcon motherIcon;
    private final JTextField displayContador = new JTextField();
    private final JLabel wii = new JLabel();
    private boolean suspendido = false;
    
    private Agente wallE;
    private Agente eva;
   
    private final BackGroundPanel fondo = new BackGroundPanel(new ImageIcon("imagenes/surface.jpg"));
    
    private final JMenu settings = new JMenu("Settigs");
    private final JRadioButtonMenuItem obstacle = new JRadioButtonMenuItem("Obstacle");
    private final JRadioButtonMenuItem sample = new JRadioButtonMenuItem("Sample");
    private final JRadioButtonMenuItem motherShip = new JRadioButtonMenuItem("MotherShip");
    
    public Escenario()
    {
        this.setContentPane(fondo);
        this.setTitle("Agentes");
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.setBounds(50,50,(dim*50+35)+185,dim*50+85); //50,50,dim*50+35,dim*50+85    ancho: 720
        initComponents();
    }
        
    private void initComponents()
    {
        ButtonGroup settingsOptions = new ButtonGroup();
        settingsOptions.add(sample);
        settingsOptions.add(obstacle);       
        settingsOptions.add(motherShip);
        
        JLabel contadorSamples  = new JLabel("Samples recogidos: ");
        
        JMenuBar barraMenus = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem run  = new JMenuItem("Run");
        JMenuItem restart  = new JMenuItem("Restart");
        JMenuItem exit   = new JMenuItem("Exit");
        // setBounds(x, y, WIDTH, HEIGHT);
        contadorSamples.setBounds(550,30,130,30);
        displayContador.setBounds(550,70,120,50);
        wii.setBounds(550,150,100,74);
        
        contadorSamples.setForeground(Color.white);
        displayContador.setBackground(Color.black);
        displayContador.setForeground(Color.white);
        displayContador.setFont(new Font("Arial", Font.BOLD, 26));
        displayContador.setHorizontalAlignment(JTextField.RIGHT);
        displayContador.setEditable(false);
        
        this.setJMenuBar(barraMenus);
        barraMenus.add(file);
        barraMenus.add(settings);
        file.add(run);
        file.add(restart);
        file.add(exit);
        settings.add(motherShip);
        settings.add(obstacle);
        settings.add(sample);
        
        add(contadorSamples);
        add(displayContador);
        add(wii);
        
        robot1 = new ImageIcon("imagenes/wall-e.png");
        robot1 = new ImageIcon(robot1.getImage().getScaledInstance(50,50,  java.awt.Image.SCALE_SMOOTH));
        
        robot2 = new ImageIcon("imagenes/eva.png");
        robot2 = new ImageIcon(robot2.getImage().getScaledInstance(50,50,  java.awt.Image.SCALE_SMOOTH));
        
        obstacleIcon = new ImageIcon("imagenes/bomb.png");
        obstacleIcon = new ImageIcon(obstacleIcon.getImage().getScaledInstance(50,50,  java.awt.Image.SCALE_SMOOTH));
        
        sampleIcon = new ImageIcon("imagenes/sample.png");
        sampleIcon = new ImageIcon(sampleIcon.getImage().getScaledInstance(50,50,  java.awt.Image.SCALE_SMOOTH));
        
        motherIcon = new ImageIcon("imagenes/mothership.png");
        motherIcon = new ImageIcon(motherIcon.getImage().getScaledInstance(50,50,  java.awt.Image.SCALE_SMOOTH));
        
        this.setLayout(null);
        formaPlano();  
        
        exit.addActionListener(evt -> gestionaSalir(evt));
        run.addActionListener(evt -> gestionaRun(evt));
        restart.addActionListener(evt -> gestionaRestart(evt));
        obstacle.addItemListener(evt -> gestionaObstacle(evt));
        sample.addItemListener(evt -> gestionaSample(evt));
        motherShip.addItemListener(evt -> gestionaMotherShip(evt));

              
            
        class MyWindowAdapter extends WindowAdapter
        {
            public void windowClosing(WindowEvent eventObject)
            {
		goodBye();
            }
        }
        addWindowListener(new MyWindowAdapter());
        
        // Crea 2 agentes
        wallE = new Agente("Wall-E",robot1, matrix, tablero, this, motherIcon); 
        eva = new Agente("Eva",robot2, matrix, tablero, this, motherIcon); 
        
    }
        
    private void gestionaSalir(ActionEvent eventObject)
    {
        goodBye();
    }
        
    private void goodBye()
    {
        int respuesta = JOptionPane.showConfirmDialog(rootPane, "Desea salir?","Aviso",JOptionPane.YES_NO_OPTION);
        if(respuesta==JOptionPane.YES_OPTION) System.exit(0);
    }
  
    private void formaPlano()
    {
        tablero = new JLabel[dim][dim];
        matrix = new int[dim][dim];
        int i, j;
        
        for(i=0;i<dim;i++)
            for(j=0;j<dim;j++)
            {
                matrix[i][j]=0;
                tablero[i][j]=new JLabel();
                tablero[i][j].setBounds(j*50+10,i*50+10,50,50);
                tablero[i][j].setBorder(BorderFactory.createDashedBorder(Color.white));
                tablero[i][j].setOpaque(false);
                this.add(tablero[i][j]);
                
                tablero[i][j].addMouseListener(new MouseAdapter() // Este listener nos ayuda a agregar poner objetos en la rejilla
                    {
                        @Override
                        public void mousePressed(MouseEvent e) 
                        {
                               insertaObjeto(e);
                        }   
                
                        @Override
                        public void mouseReleased(MouseEvent e) 
                        {
                                insertaObjeto(e);
                        }   
                    });
            }
    }
        
    private void gestionaObstacle(ItemEvent eventObject)
    {
        JRadioButtonMenuItem opt = (JRadioButtonMenuItem) eventObject.getSource();
        if(opt.isSelected())
           actualIcon = obstacleIcon;
        else actualIcon = null;        
    }
    
    private void gestionaSample(ItemEvent eventObject)
    {
        JRadioButtonMenuItem opt = (JRadioButtonMenuItem) eventObject.getSource();
        if(opt.isSelected())
           actualIcon = sampleIcon;
        else actualIcon = null;   
    }
    
    private void gestionaMotherShip(ItemEvent eventObject)
    {
        JRadioButtonMenuItem opt = (JRadioButtonMenuItem) eventObject.getSource();
        if(opt.isSelected())
           actualIcon = motherIcon;
        else actualIcon = null;   
    }
    
    private void gestionaRun(ActionEvent eventObject)
    {
        if(!wallE.isAlive()) wallE.start();
        if(!eva.isAlive()) eva.start();
        settings.setEnabled(false);
    }
    
    private void gestionaRestart(ActionEvent eventObject)
    {
        actualIcon = null;
        suspendido = true;
        
        if(wallE.isAlive()) wallE.suspend();
        if(eva.isAlive()) eva.suspend();
        
        int i, j;
        for(i=0;i<dim;i++)
            for(j=0;j<dim;j++)
            {
                if(tablero[i][j].getIcon() == obstacleIcon || tablero[i][j].getIcon() == motherIcon || tablero[i][j].getIcon()==sampleIcon)
                {
                    tablero[i][j].setIcon(actualIcon);
                }
            }
        displayContador.setText("");
        settings.setEnabled(true);
        wii.setIcon(null);
        
        
        wallE.resume();
        eva.resume();
        //settings.setEnabled(true);
        suspendido = false;
        //(gestionaRun(eventObject);       
        //settings.setEnabled(false);
    }
       
    public void insertaObjeto(MouseEvent e)
    {
        JLabel casilla = (JLabel) e.getSource();
        
        if(actualIcon!=null) casilla.setIcon(actualIcon); 
    }
    
    public boolean detectaObstaculo(int i, int j, boolean carryingSample) {
        boolean hayObstaculo=false;
        
        if(!(i<0 || j<0 || i>matrix.length - 1 || j>matrix.length - 1)){
            if(tablero[i][j].getIcon() == obstacleIcon || tablero[i][j].getIcon() == motherIcon
                        || (carryingSample && tablero[i][j].getIcon()==sampleIcon)){
                hayObstaculo=true;
            } 
        }
        else{
            if(i<0 && !(j<0 || j>matrix.length - 1)){
                if(tablero[matrix.length - 1][j].getIcon()==obstacleIcon || tablero[matrix.length-1][j].getIcon() == motherIcon 
                        || (carryingSample && tablero[matrix.length - 1][j].getIcon()==sampleIcon))
                    hayObstaculo=true;
            }

            else if(j<0 && !(i<0 || i>matrix.length - 1)){
                if(tablero[i][matrix.length - 1].getIcon()==obstacleIcon || tablero[i][matrix.length-1].getIcon() == motherIcon
                        || (carryingSample && tablero[i][matrix.length - 1].getIcon()==sampleIcon))
                    hayObstaculo=true;
            }

            else if(i>matrix.length - 1 && !(j<0 || j>matrix.length - 1)){
                if(tablero[0][j].getIcon()==obstacleIcon || tablero[0][j].getIcon() == motherIcon
                        || (carryingSample && tablero[0][j].getIcon()==sampleIcon))
                    hayObstaculo=true;
            }

            else if(j>matrix.length - 1 && !(i<0 || i>matrix.length - 1)){
                if(tablero[i][0].getIcon()==obstacleIcon || tablero[i][0].getIcon() == motherIcon
                        || (carryingSample && tablero[i][0].getIcon()==sampleIcon))
                    hayObstaculo=true;
            }
        }
      
        return hayObstaculo;
    }
    
    public boolean detectarSample(int i, int j) {
        boolean sampleDetectado=false;
        
        if(tablero[i][j].getIcon()==sampleIcon)
            sampleDetectado = true;
        
        return sampleDetectado;
    }
    
    public void cuentaSamples(){
        int x,y;
        
        contadorSamples=0;
        
        for (x = 0; x < dim; x++) {
            for (y = 0; y < dim; y++) {
                if (tablero[x][y].getIcon() == sampleIcon) {
                    contadorSamples++;
                }
            }
        }
        
    }
    
    public boolean detectarNave(int i, int j, boolean carryingSample) {
        boolean naveDetectada=false;
        
        if(!(i<0 || j<0 || i>matrix.length - 1 || j>matrix.length - 1)){
            if(tablero[i][j].getIcon() == motherIcon){
                naveDetectada=true;
        } 
        }
        else{
            if(i<0 && !(j<0 || j>matrix.length - 1)){
                if(tablero[matrix.length-1][j].getIcon() == motherIcon)
                    naveDetectada=true;
            }

            else if(j<0 && !(i<0 || i>matrix.length - 1)){
                if(tablero[i][matrix.length-1].getIcon() == motherIcon)
                    naveDetectada=true;
            }

            else if(i>matrix.length - 1 && !(j<0 || j>matrix.length - 1)){
                if(tablero[0][j].getIcon() == motherIcon)
                    naveDetectada=true;
            }

            else if(j>matrix.length - 1 && !(i<0 || i>matrix.length - 1)){
                if(tablero[i][0].getIcon() == motherIcon)
                    naveDetectada=true;
            }
        }
        
        if(naveDetectada && carryingSample){
            contadorSamples--;
            contador++;
            
            displayContador.setText("" + contador);
            wii.setIcon(new ImageIcon("imagenes/yes.GIF"));
        }
        else
            wii.setIcon(null);
            
        
        return naveDetectada;
    }

}