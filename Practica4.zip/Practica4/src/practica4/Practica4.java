/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4;

/**
 *
 * @author macario
 */
public class Practica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Persona alumno1 = new Alumno("LPPS010101HH1", "Sandra López Pérez", "Independencia No. 1", "Contador Público","5CV1");
        Persona docente1 = new Docente("LOCM680227A42","Marco López Carranza", "Hidalgo No. 5","Ecuaciones Diferenciales", "Matutino");
        Persona autoridad1 = new Autoridad("PEJE701010HH2", "Ernesto Pérez Juárez", "Juarez No. 20", "Jefe de Departamento", "P3");
        
        alumno1.showData();
        docente1.showData();
        autoridad1.showData();
        
        ((Alumno)alumno1).aprender("Paradigmas de Programación");
        ((Docente)docente1).pagar(500);
        ((Autoridad) autoridad1).declarar(2020);
        
        System.out.println("\nFin del programa...\n");
    }
    
}
