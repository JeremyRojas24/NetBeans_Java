/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

/**
 *
 * @author macario
 */
public abstract class Persona {
    
    private String rfc;
    private String nombre;
    private String domicilio;
    
    public Persona(String rfc, String nombre, String domicilio)
    {
        this.rfc = rfc;
        this.nombre = nombre;
        this.domicilio = domicilio;
    }
    
    public void showData()
    {
        System.out.println("=========================");
        System.out.println("RFC: " + this.rfc);
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Domicilio: " + this.domicilio);
       
    }
    
}
