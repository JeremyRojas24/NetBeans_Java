/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

/**
 *
 * @author macario
 */
public class Alumno extends Persona implements Aprendiz {
    
    private String carrera;
    private String grupo;

    public Alumno (String rfc, String nombre, String domicilio, String carrera, String grupo)
    {
        super(rfc, nombre, domicilio);
        this.carrera = carrera;
        this.grupo = grupo;
        
    }
    
    public void showData()
    {
        System.out.println("DATOS DEL ALUMNO");
        super.showData(); 
        System.out.println("Carrera: " + this.carrera );
        System.out.println("Grupo: " + this.grupo);
        System.out.println("=========================\n");
        
    }
    
    public void aprender(String asignatura)
    {
        System.out.println("Alumno aprendiendo " + asignatura);
    }
    
    public void acreditar(String asignatura)
    {
        System.out.println("Alumno acreditando" + asignatura);
    } 
}
