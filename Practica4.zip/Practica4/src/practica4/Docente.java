/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

/**
 *
 * @author macario
 */
public class Docente extends Persona implements Contribuyente {
    
    private String asignatura;
    private String turno;
    
    public Docente (String rfc, String nombre, String domicilio, String asignatura, String turno)
    {
        super(rfc, nombre, domicilio);
        this.asignatura = asignatura;
        this.turno = turno;
        
    }
    
    public void showData()
    {
        System.out.println("DATOS DEL DOCENTE");
        super.showData();
        System.out.println("Asignatura: " + this.asignatura);
        System.out.println("Turno: " + this.turno);
        System.out.println("=========================\n");
    }
    
    public void declarar(int year)
    {
        System.out.println("Docente haciendo declaración del año " + year);
    }
    
      
    public void pagar(double cantidad)
    {
        System.out.println("Docente haciendo pago de $" + cantidad);
    }  
    
}
