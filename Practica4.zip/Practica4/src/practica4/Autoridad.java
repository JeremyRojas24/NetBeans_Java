/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

/**
 *
 * @author macario
 */
public class Autoridad extends Persona implements Contribuyente {
    
    private String cargo;
    private String nivel;
    
    public Autoridad (String rfc, String nombre, String domicilio, String cargo, String nivel)
    {
        super(rfc, nombre, domicilio);
        this.cargo = cargo;
        this.nivel = nivel;
        
    }
    
    
    public void showData()
    {
        System.out.println("DATOS DEL FUNCIONARIO");
        super.showData();
        System.out.println("Cargo: " + this.cargo);
        System.out.println("Nivel: " + this.nivel);
        System.out.println("=========================\n");
    }
    
    public void declarar(int year)
    {
        System.out.println("Funcionario haciendo declaración del año " + year);
    }
    
      
    public void pagar(double cantidad)
    {
        System.out.println("Funcionario haciendo pago de $" + cantidad);
    }  
    
}
