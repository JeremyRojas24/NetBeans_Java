/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package practica4;

/**
 *
 * @author macario
 */
public interface Contribuyente {
    
    public void declarar(int year);
    public void pagar(double cantidad);
    
}
