/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectovideojuegos;

/**
 *
 * @author jrrm
 */
public class Videojuego {
    private String upc;
    private String descripcion;
    private String desarrollador;
    private String plataforma;
    private String clasificacion;
    private String genero;
    private String precio;
    private String imagen;
    
    // Constructor
    public Videojuego (String upc, String descripcion, String desarrollador, String precio)
    {
        this.upc = upc;
        this.descripcion = descripcion;
        this.desarrollador = desarrollador;
        //this.plataforma = plataforma;
        //this.clasificacion = clasificacion;
        //this.genero = genero;
        this.precio = precio;
        //this.imagen = imagen;
    }      
    
    // Métodos get
    public String getUpc ()
    {
        return this.upc;
    }   
   
    public String getDescripcion ()
    {
        return this.descripcion;
    }     
    
    public String getDesarrollador ()
    {
        return this.desarrollador;
    } 

    /*public String getPlataforma ()
    {
        return this.plataforma;
    } 
    
    public String getClasificacion ()
    {
        return this.clasificacion;
    }   
   
    public String getGenero ()
    {
        return this.genero;
    }*/
    
    public String getPrecio ()
    {
        return this.precio;
    } 

    /*public String getImagen ()
    {
        return this.imagen;
    }*/ 
    
    // Métodos set
    public void setUpc (String upc)
    {
        this.upc = upc;
    }
    
    public void setDescripcion (String descripcion)
    {
        this.descripcion = descripcion;
    }
    
    public void setDesarrollador (String desarrollador)
    {
        this.desarrollador = desarrollador;
    }
        
    /*public void setPlataforma (String plataforma)
    {
        this.plataforma = plataforma;
    }
  
    public void setClasificacion (String clasificacion)
    {
        this.clasificacion = clasificacion;
    }
       
    public void setGenero (String genero)
    {
        this.genero = genero;
    }*/
        
    public void setPrecio (String precio)
    {
        this.precio = precio;
    }
  
    /*public void setImagen (String imagen)
    {
        this.imagen = imagen;
    }*/
    
    public String getData()
    {
        String data = "";
        data = data.concat("\nUPC                 : " + this.upc);
        data = data.concat("\nDescripcion    : " + this.descripcion);
        data = data.concat("\nDesarrollador  : " + this.desarrollador);
        data = data.concat("\nPrecio             : " + this.precio);
        
        return data;
    }
    
}
