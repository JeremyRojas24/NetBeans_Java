/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectovideojuegos;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;


/**
 *
 * @author jrrm
 */
public class Vista extends JFrame
{
    
    private final JLabel cuadroImagenC = new JLabel();
    private final JLabel cuadroImagenV = new JLabel();
    
    // Cajas de Texto
    private JTextField upc = new JTextField();
    private JTextField descripcion = new JTextField();
    private JTextField desarrollador = new JTextField();
    private JTextField precio = new JTextField();
    
    // Lista desplegable
    private final JComboBox plataforma = new JComboBox();
    
    // Casillas de verificación
    private final JCheckBox shooter = new JCheckBox("Shooter");
    private final JCheckBox deportes = new JCheckBox("Deportes");
    private final JCheckBox multijugador = new JCheckBox("Multijugador");
    private final JCheckBox peleas = new JCheckBox("Peleas");
    private final JCheckBox carreras = new JCheckBox("Carreras");
    private final JCheckBox accion = new JCheckBox("Accion/Aventura");
    private final JCheckBox musical = new JCheckBox("Musical");
    private final JCheckBox terror = new JCheckBox("Terror");
    
    // Radio Botone
    private final ButtonGroup clasificacion = new ButtonGroup();
    private final JRadioButton everyone = new JRadioButton("Everyone");
    private final JRadioButton everyone10 = new JRadioButton("Everyone 10+");
    private final JRadioButton teen = new JRadioButton("Teen");
    private final JRadioButton mature = new JRadioButton("Mature 17+");
    private final JRadioButton adults = new JRadioButton("Adults Only 18+");
    private final JRadioButton rp = new JRadioButton("Rating Pending");
    
    // Botones de acción
    private final JButton btOpenFile = new JButton();
    private final JButton btProcesar = new JButton("Procesar");
    private final JButton btRestablecer  = new JButton("Restablecer");
     
    // Variables auxiliares
    File archivoImagen;
    
    public Vista() // Constructor
    {
        this.setTitle("GamePlanet");
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        // setBounds(x, y, WIDTH, HEIGHT);
        this.setBounds(50,50,610,680);
        
        initComponents();
  
        this.setVisible(true);
    }
    
    public void initComponents()
    {
        // Etiquetas
        JLabel etUPC = new JLabel("UPC (12-digit):");
        JLabel etDescripcion = new JLabel("Descripción:");
        JLabel etDesarrollador = new JLabel("Desarrollador:");
        JLabel etPlataforma = new JLabel("Plataforma: ");
        JLabel etClasificacion = new JLabel("Clasificación ESRB:");
        JLabel etGeneros = new JLabel("Géneros:");
        JLabel etPrecio = new JLabel("Precio:");
        JLabel etImagen = new JLabel("Imagen: ");

        // Diseña menú
        JMenuBar barraMenus = new JMenuBar();
	JMenu archivo 	  = new JMenu("Archivo");
	JMenuItem salir   = new JMenuItem("Salir");
        this.setJMenuBar(barraMenus);
        barraMenus.add(archivo);
        archivo.add(salir);

        // Elementos del ComboBox plataforma
        plataforma.addItem("PS4");
        plataforma.addItem("PS5");
        plataforma.addItem("Xbox One");
        plataforma.addItem("Xbox Series S/X");
        plataforma.addItem("Nintendo Switch");
        plataforma.addItem("PC");
        plataforma.setSelectedIndex(1); //es lo que va a aparecer por default
        
        // Radio Botones
        everyone.setActionCommand("Everyone -> Todos");
        everyone10.setActionCommand("Everyone+10 -> Todos+10");
        teen.setActionCommand("Teen -> Adolescentes");        
        mature.setActionCommand("Mature -> Maduro +17");
        adults.setActionCommand("Adults -> Adultos Únicamente +18");
        rp.setActionCommand("Rating Pending -> Aún Sin Clasificar");  
        clasificacion.add(everyone);
        clasificacion.add(everyone10);
        clasificacion.add(teen);
        clasificacion.add(mature);
        clasificacion.add(adults);
        clasificacion.add(rp);
        everyone.setSelected(true);        
       
        // Casillas de Verificación
        shooter.setActionCommand("001");
        deportes.setActionCommand("002");
        multijugador.setActionCommand("003");
        peleas.setActionCommand("004");
        carreras.setActionCommand("005");
        accion.setActionCommand("006");
        musical.setActionCommand("007");
        terror.setActionCommand("008");
        
        // Tamaño y posición
        this.setLayout(null);
        // setBounds(x, y, WIDTH, HEIGHT);
        etUPC.setBounds(50,30,100,30); //y=+40
        upc.setBounds(200,30,300,30);
        etDescripcion.setBounds(50,70,100,30); 
        descripcion.setBounds(200,70,300,30); 
        etDesarrollador.setBounds(50,110,100,30); 
        desarrollador.setBounds(200,110,300,30); 
        etPlataforma.setBounds(50,150,100,30);
        plataforma.setBounds(200,150,300,30);
        etClasificacion.setBounds(50,190,150,30);
        everyone.setBounds(200,190,130,20); //y=+20
        everyone10.setBounds(200,210,130,20);
        teen.setBounds(200,230,130,20);
        mature.setBounds(320,190,130,20); // para iniciar grupo x=+120
        adults.setBounds(320,210,140,20);
        rp.setBounds(320,230,130,20);
        etGeneros.setBounds(50,270,100,30);
        shooter.setBounds(200,270,130,20);
        deportes.setBounds(200,290,130,20);
        multijugador.setBounds(200,310,130,20);
        peleas.setBounds(200,330,130,20);
        carreras.setBounds(320,270,130,20); // para iniciar grupo x=+120
        accion.setBounds(320,290,140,20);
        musical.setBounds(320,310,130,20);
        terror.setBounds(320,330,130,20);
        etPrecio.setBounds(50,360,100,30);
        precio.setBounds(200,360,300,30);
        etImagen.setBounds(50,400,100,30);
        
        btOpenFile.setBounds(219,410,50,50);
        cuadroImagenC.setBounds(470,200,80,112);
        cuadroImagenV.setBounds(300,410,120,150);
        btProcesar.setBounds(200,577,120,30);
        btRestablecer.setBounds(370,577,120,30);
         
        // Características de los componentes
        btOpenFile.setToolTipText("Abrir archivo desde disco");
        btOpenFile.setIcon(new ImageIcon("img_app/open.png"));
        cuadroImagenC.setBorder(BorderFactory.createLineBorder(Color.black));
        cuadroImagenC.setHorizontalAlignment(SwingConstants.CENTER);
        cuadroImagenV.setBorder(BorderFactory.createLineBorder(Color.black));
        cuadroImagenV.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Agrega Componentes
        this.add(etUPC); 
        this.add(upc);
        this.add(etDescripcion); 
        this.add(descripcion); 
        this.add(etDesarrollador);
        this.add(desarrollador); 
        this.add(etPlataforma);
        this.add(plataforma);
        this.add(etClasificacion);
        this.add(everyone);
        this.add(everyone10);
        this.add(teen);
        this.add(mature);
        this.add(adults);
        this.add(rp);
        this.add(etGeneros);
        this.add(shooter);
        this.add(deportes);
        this.add(multijugador);
        this.add(peleas);
        this.add(carreras);
        this.add(accion);
        this.add(musical);
        this.add(terror);
        this.add(etPrecio);
        this.add(precio);
        this.add(etImagen);
        this.add(cuadroImagenC);
        this.add(btOpenFile);
        this.add(cuadroImagenV);
        this.add(btProcesar);
        this.add(btRestablecer);

        // Lo que se debe hacer cuando el usuario elija la opción "Salir" 
        salir.addActionListener(evt -> gestionaSalir(evt));
        
        // Eventos de botones
        everyone.addActionListener(evt -> gestionaESRB(evt));
        everyone10.addActionListener(evt -> gestionaE10(evt));
        teen.addActionListener(evt -> gestionaESRB(evt));
        mature.addActionListener(evt -> gestionaESRB(evt));
        adults.addActionListener(evt -> gestionaESRB(evt));
        rp.addActionListener(evt -> gestionaESRB(evt));
        btOpenFile.addActionListener(evt -> gestionaOpenFile(evt));
        btProcesar.addActionListener(evt -> gestionaProcesar(evt));
        btRestablecer.addActionListener(evt -> gestionaRestablecer(evt));
        
        // Lo que se debe hacer cuando el usurio elija la "X" de la ventana para salir      
        class MyWindowAdapter extends WindowAdapter
	{
            @Override
            public void windowClosing(WindowEvent e)
            {
		exit(); 
            }
	}
        addWindowListener(new MyWindowAdapter());
    }
    
    // Gestiona opción de menú "Salir"
    public void gestionaSalir(java.awt.event.ActionEvent evt)
    {
        exit();
    }
    
    public void exit()
    {
        int respuesta = JOptionPane.showConfirmDialog(rootPane, "Desea salir?","Aviso",JOptionPane.YES_NO_OPTION);
        if(respuesta==JOptionPane.YES_OPTION) System.exit(0);
    }
    
    public void gestionaESRB(java.awt.event.ActionEvent evt)
    {
        String textoBoton = evt.getActionCommand();
        char simbolo = textoBoton.charAt(0);
        if(simbolo=='E')
            cuadroImagenC.setIcon(new ImageIcon("img_esrb/everyone.png"));
        else if(simbolo=='T')
            cuadroImagenC.setIcon(new ImageIcon("img_esrb/teen.png"));
        else if(simbolo=='M')
            cuadroImagenC.setIcon(new ImageIcon("img_esrb/mature.png"));
        else if(simbolo=='A')
            cuadroImagenC.setIcon(new ImageIcon("img_esrb/adults.png"));
        else
            cuadroImagenC.setIcon(new ImageIcon("img_esrb/rp.png"));
    }
    
    public void gestionaE10(java.awt.event.ActionEvent evt)
    {
        cuadroImagenC.setIcon(new ImageIcon("img_esrb/10+.png"));
    }
            
    public void gestionaOpenFile(java.awt.event.ActionEvent evt)
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")+"/img_rep"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF & PNG", "jpg", "gif", "png");
        fileChooser.setFileFilter(filter);
        int seleccion = fileChooser.showOpenDialog(this);
        if (seleccion == JFileChooser.APPROVE_OPTION)
        {
             archivoImagen = fileChooser.getSelectedFile();
             ImageIcon imagenCargada = new ImageIcon(archivoImagen.getAbsolutePath());
             double w = imagenCargada.getIconWidth();
             double h = imagenCargada.getIconHeight();
             
             // Redimensionar la imagen
             if(h > 150 ||  w > 120)
             {
                 double r;
                 if( h > w)
                    r = 150.0/h;
                 else
                    r = 120.0/w;
                 w = w*r;
                 h = h*r;
                 Image imagenOriginal = imagenCargada.getImage();
                 Image imagenRedimensionada = imagenOriginal.getScaledInstance((int)w, (int)h, java.awt.Image.SCALE_SMOOTH);
                 imagenCargada = new ImageIcon(imagenRedimensionada);
                 
            }         
            cuadroImagenV.setBounds(300,410,imagenCargada.getIconWidth(), imagenCargada.getIconHeight());
            cuadroImagenV.setIcon(imagenCargada);
            
        }
    }
    
    public void gestionaProcesar(java.awt.event.ActionEvent evt)
    {
       String sPlataforma = (String) plataforma.getSelectedItem();
       String sClasificacion=clasificacion.getSelection().getActionCommand();
       String sGeneros="";
       String nombreArchivoImagen="no hay";
       if (archivoImagen!=null) nombreArchivoImagen = archivoImagen.getName();
       
       if(shooter.isSelected()) sGeneros+= shooter.getActionCommand()+" ";
       if(deportes.isSelected()) sGeneros+= deportes.getActionCommand()+" ";
       if(multijugador.isSelected()) sGeneros+= multijugador.getActionCommand()+" ";
       if(peleas.isSelected()) sGeneros+= peleas.getActionCommand()+" ";
       if(carreras.isSelected()) sGeneros+= carreras.getActionCommand()+" ";
       if(accion.isSelected()) sGeneros+= accion.getActionCommand()+" ";
       if(musical.isSelected()) sGeneros+= musical.getActionCommand()+" ";
       if(terror.isSelected()) sGeneros+= terror.getActionCommand()+" ";
       
       String resultados = "";
       resultados = resultados.concat("\nPlataforma      : " + sPlataforma);
       resultados = resultados.concat("\nClasificación  : " + sClasificacion);
       resultados = resultados.concat("\nGéneros         : " + sGeneros);
       resultados = resultados.concat("\nImagen          : " + nombreArchivoImagen);
       
       String cUPC = upc.getText().toUpperCase();
       String cDescripcion = descripcion.getText();
       String cDesarrollador = desarrollador.getText();
       String cPrecio = precio.getText();
       
       Videojuego myVideogame = new Videojuego(cUPC, cDescripcion, cDesarrollador, cPrecio);
       String datos;
       datos = "\nDATOS DEL VIDEOJUEGO\n";
       datos = datos.concat(myVideogame.getData());
       JOptionPane.showMessageDialog(rootPane, datos + resultados, "Resultados", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void gestionaRestablecer(java.awt.event.ActionEvent evt)
    {
       upc.setText("");
       descripcion.setText("");
       desarrollador.setText("");
       plataforma.setSelectedIndex(1);
       everyone.setSelected(true);
       cuadroImagenC.setIcon(null);
       shooter.setSelected(false);
       deportes.setSelected(false);
       multijugador.setSelected(false);
       peleas.setSelected(false);
       carreras.setSelected(false);
       accion.setSelected(false);
       musical.setSelected(false);
       terror.setSelected(false);
       precio.setText("");
       archivoImagen = null;       
       cuadroImagenV.setBounds(300,410,120,150);
       cuadroImagenV.setIcon(null);
    }
    
}
