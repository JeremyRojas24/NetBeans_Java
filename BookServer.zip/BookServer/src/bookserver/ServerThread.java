/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookserver;
import java.io.*;
import java.net.*;
import java.util.Properties;
import org.json.JSONObject;
import org.json.JSONArray;
import java.sql.ResultSet;
import javax.swing.ImageIcon;

/**
 *
 * @author Macario
 */
public class ServerThread extends Thread
{
 
    Socket skCliente;

    public ServerThread(Socket socket)
    {
	this.skCliente = socket;
    }
        
    public void run()
    {
        try
        {
                InputStream flujoEntrada = skCliente.getInputStream(); // Se obtiene el flujo de entrada del socket
                ObjectInputStream entrada = new ObjectInputStream( flujoEntrada );
                String peticion = (String) entrada.readObject();
                JSONObject jsonPeticion = new JSONObject(peticion);
                System.out.println(jsonPeticion.toString());
                
                String operacion = jsonPeticion.getString("operacion");
                String dato      = jsonPeticion.getString("dato");
                System.out.println("El cliente pide: "+ operacion);
  
                // Flujo de salida para emviar la respuesta
                OutputStream flujoSalida = skCliente.getOutputStream();
                ObjectOutputStream salida = new ObjectOutputStream( flujoSalida );
                
                // Atiente la operación solicitada
                
                switch(operacion)
                {
                    case "consultar": // El cliente solicita los datos de todos los libros
                    {    
                        JSONObject jsonRespuesta = new JSONObject();
                   
                        // Busca el libro en la BD
                        Properties props=new Properties();
                        props.load(new FileInputStream("config.properties"));
    
                        ResultSet rs = Libro.getLibrosFromDB(props);
                   
                        if(rs!= null)
                        { 
                            JSONArray todosLibros = new JSONArray();

                            while(rs.next())
                            {    
                                JSONObject jsonLibro = new JSONObject(); // Crea el json para la res´puesta
    
                                jsonLibro.put("isbn", rs.getString("isbn"));
                                jsonLibro.put("titulo", rs.getString("titulo"));
                                jsonLibro.put("autor", rs.getString("autor"));
                                jsonLibro.put("editorial", rs.getString("editorial"));
                                jsonLibro.put("precio",rs.getString("precio"));
                                jsonLibro.put("imagen", rs.getString("imagen"));
                            
                                todosLibros.put(jsonLibro);                                                        
                            }
                        
                            jsonRespuesta.put("libros", todosLibros);
                            jsonRespuesta.put("status", "200");
                            salida.writeObject(jsonRespuesta.toString());
                            System.out.println("Enviado: 200 Ok!");
                        }
                        else
                        {   
                            jsonRespuesta.put("status", "404");
                            System.out.println("Enviado: 404 Not found!");
                        
                        }
                    }; break;
                    
                    case "imagen": // El cliente solicita la imagen de una portada
                    {                        
                        ImageIcon respuesta = new ImageIcon("imagenes/" +dato);                  
                        salida.writeObject(respuesta);
                        System.out.println("Enviado el archivo imagenes/"+dato);                        
                    }; break;
                    
                    case "test": // El cliente manda un mensaje de prueba
                    {                        
                        JSONObject jsonRespuesta = new JSONObject();
                        jsonRespuesta.put("status", "200");
                        jsonRespuesta.put("dato", "welcome");
                        salida.writeObject(jsonRespuesta.toString());                      
                    }; break;                    
                }
                skCliente.close();
        }
        catch(Exception ex)
        {
                ex.printStackTrace();
        }
    }
}
