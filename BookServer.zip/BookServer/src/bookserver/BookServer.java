/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookserver;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Macario
 */
public class BookServer 
{

    static final int puerto=5000;
    
    public BookServer()
    {

        try
        {
            InetAddress localHost = InetAddress.getLocalHost();
            ServerSocket skServidor = new ServerSocket( puerto );
            System.out.println("SERVIDOR-> Dirección IP:  " + localHost.getHostAddress()+" Puerto: " + puerto );

            int numPet = 0;

            while (true) // Ciclo infinito, esperando peticiones
            {
                         
                numPet++;

                Socket skCliente = skServidor.accept(); // Espera hasta que llegue una conexion de un cliente y la acepta
                System.out.println("Peticion: " + numPet);
                
                ServerThread hilo = new ServerThread(skCliente); // Cada petición del cliente será atendido por un hilo 
                hilo.start(); // Inicia el hilo para atender la petición del cliente

            }
        }
        catch( Exception ex )
        {
	       ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) 
    {
       new BookServer();
    }
    
}
