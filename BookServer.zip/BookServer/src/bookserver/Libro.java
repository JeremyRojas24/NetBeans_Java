/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class Libro
{

	private String isbn;
	private String titulo;
	private String autor;
        private String editorial;
	private String imagen;
	private double precio;

	public Libro()
	{}

	public Libro(String isbn, String titulo, String autor, String editorial, String imagen, double precio)
	{
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
                this.editorial = editorial;
		this.imagen = imagen;
		this.precio = precio;

	}

	// Metodos get

	public String getIsbn()
	{
		return isbn;
	}

	public String getTitulo()
	{
		return titulo;
	}

	public String getAutor()
	{
		return autor;
	}
        
        public String getEditorial()
        {
            return editorial;
        }

	public String getImagen()
	{
		return imagen;
	}

	public  double getPrecio()
	{
		return precio;
	}

	// Métodos set

	public void setIsbn(String isbn)
	{
		this.isbn = isbn;
	}

	public void setTitulo(String titulo)
	{
		this.titulo = titulo;
	}

	public void setAutor(String autor)
	{
		this.autor = autor;
	}

        public void setEditorial(String editorial)
        {
            this.editorial = editorial;
        }
        
	public void setImagen(String imagen)
	{
		this.imagen = imagen;
	}

	public void setPrecio(double precio)
	{
		this.precio = precio;
	}


	public void muestraDatos()
	{
		System.out.println("ISBN  :" + isbn);
		System.out.println("Titulo:" + titulo);
		System.out.println("Autor :" + autor);
                System.out.println("Editorial: " + editorial);
		System.out.println("Precio:" + precio);
	}

        // Consulta la tabla la tabla de libros y regresa el conjunto de resultados
        
	public static ResultSet getLibrosFromDB(Properties prop)
	{
            ResultSet rs = null;

            try
	    {

                String driver = prop.getProperty("dbdriver");
                String host   = prop.getProperty("dbhost");
                String user   = prop.getProperty("dbuser");
                String password = prop.getProperty("dbpassword");
                String name     = prop.getProperty("dbname");
                String url = host + name  + "?user=" + user + "&password=" + password;
                System.out.println("Conexion a la BD: " + url);


                Class.forName(driver);     // Carga el driver


                Connection con = DriverManager.getConnection(url); // Crea una conexion a la BD

                PreparedStatement ps = con.prepareStatement("SELECT * FROM LIBROS");
                rs = ps.executeQuery();
                
                if(rs!=null)
                    return rs;
                
	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    return null;
	}
      
}

