/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocalculadora;

/**
 *
 * @author jrrm
 */
public class Calculadora {
        private double memoria=0;
	private char operadorAnterior='=';
        private boolean radianes=true;


	public void operacion(double numero, char operador)
	{
            
            if(operadorAnterior=='=')
                memoria = numero;
            else
            	switch(operadorAnterior)
		{
                    case '+': memoria+=numero; break;
                    case '-': memoria-=numero; break;
                    case '*': memoria*=numero; break;
                    case '/': memoria/=numero; break;
                    case 'i': memoria=1/numero; break;
                    case 'x': memoria=Math.pow(numero, 2); break;
                    case '√': memoria=Math.sqrt(numero); break;
                    case '∛': memoria=Math.cbrt(numero); break;


		}
            operadorAnterior=operador;
	}
        
        public void seno(double numero)
        {
            memoria=Math.sin(numero*(Math.PI/180));
        }
        
        public void coseno(double numero)
        {
            memoria=Math.cos(numero*(Math.PI/180));
        }
        
        public void tangente(double numero)
        {
            memoria=Math.tan(numero*(Math.PI/180));
        }
        
        public void clearMemory()
        {
            memoria=0;
        }
        
	public double getMemoria()
	{
		return memoria;
	}
        
        //originalmente decìa radianes=false pero estaba mal jaja
        public void setRadianes()
        {
            radianes=true;
        }
        
        public void setDegrees()
        {
            radianes=false;
        }
        
        public boolean isRadianes()
        {
            return radianes;
        }
}
