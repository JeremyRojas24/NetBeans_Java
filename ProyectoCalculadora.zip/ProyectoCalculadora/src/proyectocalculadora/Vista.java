/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocalculadora;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author jrrm
 */
public class Vista extends JFrame 
{
        // El objeto calculadora es el que realmente realiza las operaciones
    	private final Calculadora calculator = new Calculadora();
        private final JTextField display = new JTextField();

        private final JButton b0 = new JButton("0");
	private final JButton b1 = new JButton("1");
	private final JButton b2 = new JButton("2");
	private final JButton b3 = new JButton("3");
	private final JButton b4 = new JButton("4");
	private final JButton b5 = new JButton("5");
	private final JButton b6 = new JButton("6");
	private final JButton b7 = new JButton("7");
	private final JButton b8 = new JButton("8");
	private final JButton b9 = new JButton("9");
	private final JButton mas= new JButton("+");
	private final JButton menos=new JButton("-");
        private final JButton multi=new JButton("*");
        private final JButton div= new JButton("/");
        private final JButton igual=new JButton("=");
        private final JButton cE   = new JButton("CE");
        private final JButton C = new JButton("C");
        private final JButton sin = new JButton("sin");
        private final JButton cos = new JButton("cos");
        private final JButton tan = new JButton("tan");
        private final JButton inv = new JButton("inv");
        private final JButton pot2 = new JButton("x²");
        private final JButton raiz = new JButton("√");
        private final JButton ra3 = new JButton("∛");
        private final JButton eu = new JButton("e"); 
        private final JButton pi = new JButton("π");
        private final JButton feli = new JButton(":)");
        private final JButton sad = new JButton(":(");
        
        
        // Bandera lógica para para indicar el inicio de una nueva cifra
        private boolean nuevo=true;

	public Vista()
	{
		initComponents();
		this.setTitle("Calculadora");
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		this.setBounds(100,100,500,530);

		this.setVisible(true);

	}

	public void initComponents()
	{
            // Diseña el menu
            JMenuBar barraMenus = new JMenuBar();
            JMenu archivo       = new JMenu("Archivo");
            JMenuItem salir     = new JMenuItem("Salir");
            this.setJMenuBar(barraMenus);
            
            barraMenus.add(archivo);
            archivo.add(salir);

	    // Al desabilitar el LayoutManager, el programador tiene
	    // la responsabilidad de situar los componentes
            this.setLayout(null); // Se deshabilita el Gestor de Distribución
            display.setBounds(10,5,400,40);
            b1.setBounds(10,50,50,50);
            b2.setBounds(70,50,50,50);
            b3.setBounds(130,50,50,50);
            mas.setBounds(190,50,50,50);

            b4.setBounds(10,110,50,50); //los primeros son 10, +60
            b5.setBounds(70,110,50,50); //los segundos son 70, +60
            b6.setBounds(130,110,50,50); //los terceros son 130, +60
            menos.setBounds(190,110,50,50); //los cuartos son 190, +60

            b7.setBounds(10,170,50,50);
            b8.setBounds(70,170,50,50);
            b9.setBounds(130,170,50,50);
            multi.setBounds(190,170,50,50);
            
            cE.setBounds(10,230,50,50);
            C.setBounds(70,230,50,50);
            b0.setBounds(130,230,50,50);
            div.setBounds(190,230,50,50);
            
            sin.setBounds(10,290,50,50);
            cos.setBounds(70,290,50,50);
            tan.setBounds(130,290,50,50);
            igual.setBounds(190,290,50,50);
            
            inv.setBounds(10,350,50,50);
            pot2.setBounds(70,350,50,50);
            raiz.setBounds(130,350,50,50);
            ra3.setBounds(190,350,50,50);
            
            eu.setBounds(10,410,50,50);
            pi.setBounds(70,410,50,50);
            feli.setBounds(130,410,50,50);
            sad.setBounds(190,410,50,50);

            display.setBackground(Color.black);
            display.setForeground(Color.orange);
            display.setFont(new Font("Consolas",Font.BOLD, 26));
            display.setHorizontalAlignment(JTextField.RIGHT);
            display.setEditable(false);

            // Agrega los elementos al JFrame
            this.add(display);
            this.add(b1);
            this.add(b2);
            this.add(b3);
            this.add(b4);
            this.add(b5);
            this.add(b6);
            this.add(b7);
            this.add(b8);
            this.add(b9);
            this.add(b0);
            this.add(mas);
            this.add(menos);
            this.add(multi);
            this.add(div);
            this.add(igual);
            this.add(cE);
            this.add(C);
            this.add(sin);
            this.add(cos);
            this.add(tan);
            this.add(inv);
            this.add(pot2);
            this.add(raiz);
            this.add(ra3);
            this.add(eu);
            this.add(pi);
            this.add(feli);
            this.add(sad);
           
            // Para la gestión de los eventos de Calculadora
            b0.addActionListener(evt -> gestionarBotones(evt));
            b1.addActionListener(evt -> gestionarBotones(evt));
            b2.addActionListener(evt -> gestionarBotones(evt));
            b3.addActionListener(evt -> gestionarBotones(evt));
            b4.addActionListener(evt -> gestionarBotones(evt));         
            b5.addActionListener(evt -> gestionarBotones(evt));
            b6.addActionListener(evt -> gestionarBotones(evt));
            b7.addActionListener(evt -> gestionarBotones(evt));
            b8.addActionListener(evt -> gestionarBotones(evt));
            b9.addActionListener(evt -> gestionarBotones(evt));
            mas.addActionListener(evt -> gestionarBotones(evt));
            menos.addActionListener(evt -> gestionarBotones(evt));
            multi.addActionListener(evt -> gestionarBotones(evt));
            div.addActionListener(evt -> gestionarBotones(evt));
            igual.addActionListener(evt -> gestionarBotones(evt));
            C.addActionListener(evt -> gestionarBotones(evt));
            inv.addActionListener(evt -> gestionarBotones(evt));
            pot2.addActionListener(evt -> gestionarBotones(evt));
            raiz.addActionListener(evt -> gestionarBotones(evt));
            ra3.addActionListener(evt -> gestionarBotones(evt));
            sin.addActionListener(evt -> gestionarBotones(evt));
            cos.addActionListener(evt -> gestionarBotones(evt));
            tan.addActionListener(evt -> gestionarBotones(evt));
            pi.addActionListener(evt -> gestionarBotones(evt));
            eu.addActionListener(evt -> gestionarBotones(evt));
            
            // Al ser una tecla con dos símbolos en la cara 
            // les asignamos un Listener diferente   
            cE.addActionListener(evt -> gestionarCE(evt));
            feli.addActionListener(evt -> gestionarFeli(evt));
            sad.addActionListener(evt -> gestionarSad(evt));
                    
            // Gestión de menú
            salir.addActionListener(evt -> gestionarSalir(evt));
        
            // Salida 
            class MyWindowAdapter extends WindowAdapter
            {
                @Override
                public void windowClosing(WindowEvent e)
		{
                    exit();
		}
            }
            addWindowListener(new MyWindowAdapter());

	}
               
        
        // Métodos para gestión de eventos
        public void gestionarSalir(java.awt.event.ActionEvent evt)
        {
            exit();
        }
        
        public void exit()
        {
            int respuesta = JOptionPane.showConfirmDialog(rootPane, "Desea salir?","Federación deportiva",JOptionPane.YES_NO_OPTION);
            if(respuesta==JOptionPane.YES_OPTION) System.exit(0);
        }

        
        // Gestión para botones numéricos y símbolos de operación
        public void gestionarBotones(java.awt.event.ActionEvent evt)
        {

            String textoBoton = evt.getActionCommand();

            // Cada botón tiene un simbolo numérico o operador en la cara del botón
            // Se obtiene con charAt
            
            char simbolo = textoBoton.charAt(0);
                
            if( (simbolo >= '0' && simbolo <= '9') || simbolo == '.' || simbolo == 'π' || simbolo == 'e') // En caso de número
            {
                if(nuevo)
                {
                    display.setText("");
                } // Si es una nueva cifra se borra el diaplay
                    
                if(simbolo=='π') 
                    display.setText(display.getText()+Math.PI);
                else if(simbolo=='e')
                    display.setText(display.getText()+Math.E);    
                else 
                    display.setText(display.getText()+simbolo);
		nuevo = false; // Se pone en falso cuando se pone el primer dígito de una cifra
            }
            else if(simbolo=='+'||simbolo=='-'||simbolo=='*'||simbolo=='/'||simbolo=='=' ||simbolo=='√' ||simbolo=='∛' ||simbolo=='x' ||simbolo=='i') // En caso de operador
            {
		double numero = Double.parseDouble(display.getText());

		calculator.operacion(numero,simbolo);         // Invoca la funcionalidad de la calculadora

		display.setText(""+calculator.getMemoria());  // Obtiene el estado de la memoria de la calculadora

		nuevo = true;
            }
            else if(simbolo=='C') 
            {   
                display.setText("");
            }
            // Estos los tuvimos que hacer aparte porque 
            // las funciones trigo sólo les entra un solo núm para funcionar
            else if(simbolo=='s')
            {
                double numero = Double.parseDouble(display.getText());
                
                calculator.seno(numero);
                
                display.setText(""+calculator.getMemoria());
                
                nuevo=true;
            }
            else if(simbolo=='c')
            {
                double numero = Double.parseDouble(display.getText());
                
                calculator.coseno(numero);
                
                display.setText(""+calculator.getMemoria());
                
                nuevo=true; 
            }
            else if(simbolo=='t')
            {
                double numero = Double.parseDouble(display.getText());
                
                calculator.tangente(numero);
                
                display.setText(""+calculator.getMemoria());
                
                nuevo=true;
            }
        }
            
        // Gestiona botón CE
        public void gestionarCE(java.awt.event.ActionEvent evt)
        {
            // Codigo para procesar CE
            calculator.clearMemory();
            display.setText("");
            nuevo=true;
        } 
        
        // Botón cool de caritas felices
        public void gestionarFeli(java.awt.event.ActionEvent evt)
        {
            calculator.clearMemory();
            display.setText(":)");
            nuevo=true;
        }
        // Botón cool de caritas tristes
        public void gestionarSad(java.awt.event.ActionEvent evt)
        {
            calculator.clearMemory();
            display.setText(":(");
            nuevo=true;
        }
}
