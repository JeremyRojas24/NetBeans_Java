/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectogameplanet;

/**
 *
 * @author jrrm
 */

import java.awt.Image;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class Vista extends JFrame
{
    
    private final JLabel cuadroImagenV = new JLabel();
    
    // Cajas de Texto
    private JTextField upc = new JTextField();
    private JTextField descripcion = new JTextField();
    private JTextField desarrollador = new JTextField();
    private JTextField plataforma = new JTextField();
    private JTextField clasificacion = new JTextField();
    private JTextField genero = new JTextField();
    private JTextField precio = new JTextField();
    private JTextField imagen = new JTextField();
    
    // Botones de acción
    private final JButton btOpenFile = new JButton();
    private final JButton btBuscar = new JButton("Buscar");
    private final JButton btAgregar = new JButton("Agregar");
    private final JButton btEliminar = new JButton("Eliminar");
    private final JButton btCambiar = new JButton("Cambiar");
    private final JButton btLimpiar  = new JButton("Limpiar");
     
    // Variables auxiliares
    File archivoImagen;
    
    private Properties prop;
    
    private String mensajeError = "";
  
    
    public Vista(Properties prop) // Constructor
    {
        this.prop = prop;
        initComponents();
        this.setTitle("GamePlanet");
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.setLayout(null);
        // setBounds(x, y, WIDTH, HEIGHT);
        this.setBounds(50,50,710,465);
        
        // Carga las propiedades desde el archivo
	try
	{
                prop.load(new FileInputStream("config.properties"));
	}
	catch (Exception ex)
	{
		ex.printStackTrace();
	}
        
    }
    
    public void initComponents()
    {
        // Etiquetas
        JLabel etUPC = new JLabel("UPC (12-digit):");
        JLabel etDescripcion = new JLabel("Descripción:");
        JLabel etDesarrollador = new JLabel("Desarrollador:");
        JLabel etPlataforma = new JLabel("Plataforma: ");
        JLabel etClasificacion = new JLabel("Clasificación ESRB:");
        JLabel etGeneros = new JLabel("Género:");
        JLabel etPrecio = new JLabel("Precio:");
        JLabel etImagen = new JLabel("Imagen: ");

        // Diseña menú
        JMenuBar barraMenus = new JMenuBar();
	JMenu archivo 	  = new JMenu("Archivo");
	JMenuItem salir   = new JMenuItem("Salir");
        this.setJMenuBar(barraMenus);
        barraMenus.add(archivo);
        archivo.add(salir);      
        
        // Tamaño y posición
        this.setLayout(null);
        // setBounds(x, y, WIDTH, HEIGHT);
        etUPC.setBounds(50,30,100,30); //y=+40
        upc.setBounds(200,30,300,30);
        etDescripcion.setBounds(50,70,100,30); 
        descripcion.setBounds(200,70,300,30); 
        etDesarrollador.setBounds(50,110,100,30); 
        desarrollador.setBounds(200,110,300,30); 
        etPlataforma.setBounds(50,150,100,30);
        plataforma.setBounds(200,150,300,30);
        etClasificacion.setBounds(50,190,150,30);
        clasificacion.setBounds(200,190,300,30);
        etGeneros.setBounds(50,230,100,30);
        genero.setBounds(200,230,300,30);
        etPrecio.setBounds(50,270,100,30);
        precio.setBounds(200,270,300,30);
        etImagen.setBounds(50,310,100,30);
        imagen.setBounds(200,310,300,30);
        
        cuadroImagenV.setBounds(300,370,120,150);
        btBuscar.setBounds(541,30,120,30);
        btAgregar.setBounds(70,360,120,30);
        btEliminar.setBounds(200,360,120,30);
        btCambiar.setBounds(330,360,120,30);
        btLimpiar.setBounds(460,360,120,30);
         
        
        // Agrega Componentes
        this.add(etUPC); 
        this.add(upc);
        this.add(etDescripcion); 
        this.add(descripcion); 
        this.add(etDesarrollador);
        this.add(desarrollador); 
        this.add(etPlataforma);
        this.add(plataforma);
        this.add(etClasificacion);
        this.add(clasificacion);
        this.add(etGeneros);
        this.add(genero);
        this.add(etPrecio);
        this.add(precio);
        this.add(etImagen);
        this.add(imagen);
        this.add(cuadroImagenV);
        this.add(btBuscar);
        this.add(btAgregar);
        this.add(btEliminar);
        this.add(btCambiar);
        this.add(btLimpiar);

        // Lo que se debe hacer cuando el usuario elija la opción "Salir" 
        salir.addActionListener(evt -> gestionaSalir(evt));
        
        // Eventos de botones
        btBuscar.addActionListener(evt -> gestionaBuscar(evt));
        btAgregar.addActionListener(evt -> gestionaAgregar(evt));
        btEliminar.addActionListener(evt -> gestionaEliminar(evt));
        btCambiar.addActionListener(evt -> gestionaCambiar(evt));
        btLimpiar.addActionListener(evt -> gestionaLimpiar(evt));
        
        // Lo que se debe hacer cuando el usurio elija la "X" de la ventana para salir      
        class MyWindowAdapter extends WindowAdapter
	{
            @Override
            public void windowClosing(WindowEvent e)
            {
		exit(); 
            }
	}
        addWindowListener(new MyWindowAdapter());
    }
    
    // Gestiona opción de menú "Salir"
    public void gestionaSalir(java.awt.event.ActionEvent evt)
    {
        exit();
    }
    
    public void exit()
    {
        int respuesta = JOptionPane.showConfirmDialog(rootPane, "Desea salir?","Aviso",JOptionPane.YES_NO_OPTION);
        if(respuesta==JOptionPane.YES_OPTION) System.exit(0);
    }
    
    
    public void gestionaBuscar(java.awt.event.ActionEvent evt)
        {
            if(upc.getText().isBlank())
            {
		JOptionPane.showMessageDialog(this, "Para localizar un videojuego se requiere el UPC", "Aviso!", JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                Videojuego newVideogame = Videojuego.getVideojuegoFromDB(upc.getText(),prop); // Método estático para obtener un videojuego desde la BD 
		if(newVideogame != null) // Si hubo éxito
		{
                    descripcion.setText(newVideogame.getDescripcion());
                    desarrollador.setText(newVideogame.getDesarrollador());
                    plataforma.setText(newVideogame.getPlataforma());
                    clasificacion.setText(newVideogame.getClasificacion());
                    genero.setText(newVideogame.getGenero());
                    ImageIcon imagenCargada = new ImageIcon(newVideogame.getImagen());
                    double w = imagenCargada.getIconWidth();
                    double h = imagenCargada.getIconHeight();
            
                     // Redimensionar la imagen
                    if(h > 150 ||  w > 120)
                    {
                        double r;
                        if( h > w)
                            r = 150.0/h;
                        else
                            r = 120.0/w;
                        w = w*r;
                        h = h*r;
                        Image imagenOriginal = imagenCargada.getImage();
                        Image imagenRedimensionada = imagenOriginal.getScaledInstance((int)w, (int)h, java.awt.Image.SCALE_SMOOTH);
                        imagenCargada = new ImageIcon(imagenRedimensionada);
                    }         
                    cuadroImagenV.setBounds(525,80,imagenCargada.getIconWidth(), imagenCargada.getIconHeight());
                    cuadroImagenV.setIcon(imagenCargada);
                    
                    //String nombreArchivoImagen = newVideogame.getImagen();
                    //cuadroImagenV.setIcon(new ImageIcon(nombreArchivoImagen));
                    precio.setText(newVideogame.getPrecio());
                    imagen.setText(newVideogame.getImagen());
                    
		}
                else JOptionPane.showMessageDialog(this, "El videojuego con el UPC indicado no fue localizado", "Aviso!", JOptionPane.ERROR_MESSAGE);
            }
            
        }
    
    public void gestionaCambiar(java.awt.event.ActionEvent evt)
        {
            if(upc.getText().isBlank())
            {
                JOptionPane.showMessageDialog(this, "Para localizar el vieojuego que se va \na actualizar se requiere el UPC", "Aviso!", JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                
                if(!invalido()) // Se intenta realizar el UPDATE solo si no hay error de captura
                {
                    Videojuego newVideogame = Videojuego.getVideojuegoFromDB(upc.getText(),prop); // Método estático para obtener un videojuego desde la BD 
                    if(newVideogame != null)
                    {
                        newVideogame.setDescripcion(descripcion.getText()); // Actualiza la descripción del objeto videojuego
                        newVideogame.setDesarrollador(desarrollador.getText());
                        newVideogame.setPlataforma(plataforma.getText());
                        newVideogame.setClasificacion(clasificacion.getText());
                        newVideogame.setGenero(genero.getText());
                        newVideogame.setPrecio(precio.getText());
                        newVideogame.setImagen(imagen.getText());
                        
                        if(newVideogame.cambiar(prop)) // Si hubo éxito
                            JOptionPane.showMessageDialog(this, "Registro actualizado: " + upc.getText(), "Aviso!",JOptionPane.INFORMATION_MESSAGE);
                        else
                            JOptionPane.showMessageDialog(this, "Acción no realizada!!","Aviso!",JOptionPane.ERROR_MESSAGE);
                    }
                    else JOptionPane.showMessageDialog(this, "El videojuego con el UPC indicado no fue localizado", "Aviso!", JOptionPane.ERROR_MESSAGE);                    
                } 
                else JOptionPane.showMessageDialog(this, mensajeError, "Aviso!", JOptionPane.ERROR_MESSAGE);                
	    }
                                       
        }
    
    public void gestionaAgregar(java.awt.event.ActionEvent evt)
    {
            if(!invalido()) // Se intenta realizar el INSERT solo si no hay error de captura
            {               
               // Primero investigamos si no hay otro registro con el mismo UPC
                Videojuego newVideogame = Videojuego.getVideojuegoFromDB(upc.getText(),prop);
               
                if(newVideogame == null) // Solo si el ISBN no está registrado 
                {                        
                    // Adquirimos los datos de la vista              
                    newVideogame = new Videojuego();
                    newVideogame.setUpc(upc.getText());
                    newVideogame.setDescripcion(descripcion.getText());
                    newVideogame.setDesarrollador(desarrollador.getText());
                    newVideogame.setPlataforma(plataforma.getText());
                    newVideogame.setClasificacion(clasificacion.getText());
                    newVideogame.setGenero(genero.getText());
                    newVideogame.setPrecio(precio.getText());
                    newVideogame.setImagen(imagen.getText());
                    
                    
                    // Tratamos de ejecutar el alta
                                
                    if(newVideogame.alta(prop)) // Si la alta fue exitosa
                        JOptionPane.showMessageDialog(this, "Registro agregado: " + upc.getText(), "Aviso!",JOptionPane.INFORMATION_MESSAGE);
                    else
                        JOptionPane.showMessageDialog(this, "Acción no realizada!!","Aviso!",JOptionPane.ERROR_MESSAGE);                           
                }
                else JOptionPane.showMessageDialog(this, "El UPC ya está registrado", "Aviso!", JOptionPane.ERROR_MESSAGE); 
            } 
            else JOptionPane.showMessageDialog(this, mensajeError, "Aviso!", JOptionPane.ERROR_MESSAGE);         
    }
    
    public void gestionaEliminar(java.awt.event.ActionEvent evt)
        {
            if(upc.getText().isBlank())
            {
                JOptionPane.showMessageDialog(this, "Para localizar el videojuego que se va \na eliminar se requiere el UPC", "Aviso!", JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                // Solicitamos confirmación     
                int respuesta = JOptionPane.showConfirmDialog(this, "Desea borrar este registro?", "Atención!!!", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    
                if(respuesta==JOptionPane.YES_OPTION) // Si el usuario confirma
                {

                    Videojuego newVideogame = Videojuego.getVideojuegoFromDB(upc.getText(),prop); // Trata de recuperar el videojuego de la BD
                    
                    if(newVideogame != null) // Si lo encuentra
                    {
                        // Intenta eliminar el registro
                        if(newVideogame.borrar(prop)) // Si hubo éxito
                        {   
                            JOptionPane.showMessageDialog(this, "Registro eliminado: " + upc.getText(), "Aviso!",JOptionPane.WARNING_MESSAGE);
                            limpiarCampos();
                        }    
                        else JOptionPane.showMessageDialog(this, "Acción no realizada!!","Aviso!",JOptionPane.ERROR_MESSAGE);
                    }
                    else JOptionPane.showMessageDialog(this, "El videojuego con el UPC indicado no fue localizado", "Aviso!", JOptionPane.ERROR_MESSAGE);            
		}
            }
            
        }
    
    
    public void gestionaLimpiar(java.awt.event.ActionEvent evt)
    {
        limpiarCampos();
    }
    
    private void limpiarCampos()
    {
        upc.setText("");
        descripcion.setText("");
        desarrollador.setText("");
        plataforma.setText("");
        clasificacion.setText("");
        genero.setText("");
        precio.setText("");
        imagen.setText("");     
        cuadroImagenV.setBounds(300,410,120,150);
        cuadroImagenV.setIcon(null);
    }
    
    // Validación de datos
        private boolean invalido()
        {
            boolean hayError = false;
            mensajeError = "";
            
            if(upc.getText().isBlank())
            {
                hayError = true;
                mensajeError = mensajeError.concat("No debe dejar el UPC en blanco\n");
            }
            
            if(descripcion.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar la descripción en blanco\n");
            }
            
            if(desarrollador.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar el desarrollador en blanco\n");
            }
            
            if(plataforma.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar la plataforma en blanco\n");
            }
            
            if(clasificacion.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar la clasificacin en blanco\n");
            }
            
            if(genero.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar el género en blanco\n");
            }
            
            if(precio.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar el precio en blanco\n");
            }
            
            if(imagen.getText().isBlank())
            {
                        hayError = true;
                        mensajeError = mensajeError.concat("No debe dejar la imagen en blanco\n");
            }
            
            return hayError;
        }
    
}