/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectogameplanet;

/**
 *
 * @author jrrm
 */

import java.sql.*;
import java.util.*;

public class Videojuego 
{
    private String upc;
    private String descripcion;
    private String desarrollador;
    private String plataforma;
    private String clasificacion;
    private String genero;
    private String precio;
    private String imagen;
    
    public Videojuego()
    {}
    
    // Constructor
    public Videojuego (String upc, String descripcion, String desarrollador, String precio)
    {
        this.upc = upc;
        this.descripcion = descripcion;
        this.desarrollador = desarrollador;
        this.plataforma = plataforma;
        this.clasificacion = clasificacion;
        this.genero = genero;
        this.precio = precio;
        this.imagen = imagen;
    }      
    
    // Métodos get
    public String getUpc ()
    {
        return this.upc;
    }   
   
    public String getDescripcion ()
    {
        return this.descripcion;
    }     
    
    public String getDesarrollador ()
    {
        return this.desarrollador;
    } 

    public String getPlataforma ()
    {
        return this.plataforma;
    } 
    
    public String getClasificacion ()
    {
        return this.clasificacion;
    }   
   
    public String getGenero ()
    {
        return this.genero;
    }
    
    public String getPrecio ()
    {
        return this.precio;
    } 

    public String getImagen ()
    {
        return "img_rep/" + imagen;
    }
    
    // Métodos set
    public void setUpc (String upc)
    {
        this.upc = upc;
    }
    
    public void setDescripcion (String descripcion)
    {
        this.descripcion = descripcion;
    }
    
    public void setDesarrollador (String desarrollador)
    {
        this.desarrollador = desarrollador;
    }
        
    public void setPlataforma (String plataforma)
    {
        this.plataforma = plataforma;
    }
  
    public void setClasificacion (String clasificacion)
    {
        this.clasificacion = clasificacion;
    }
       
    public void setGenero (String genero)
    {
        this.genero = genero;
    }
        
    public void setPrecio (String precio)
    {
        this.precio = precio;
    }
  
    public void setImagen (String imagen)
    {
        this.imagen = imagen;
    }
    
    public void muestraDatoss()
    {
        System.out.println("UPC             :" + upc);
        System.out.println("Descripción     :" + upc);
        System.out.println("Desarrollador   :" + upc);
        System.out.println("PLataforma      :" + upc);
        System.out.println("Clasificación   :" + upc);
        System.out.println("Género          :" + upc);
        System.out.println("Precio          :" + upc);
        System.out.println("Imagen          :" + upc);
    }
    
    //Read=Select 
	public static Videojuego getVideojuegoFromDB(String upcConsulta, Properties prop)
	{
            Videojuego videojuego = new Videojuego(); // Nuevo videojuego en blanco

            try
	    {

                String driver = prop.getProperty("dbdriver");
                String host   = prop.getProperty("dbhost");
                String user   = prop.getProperty("dbuser");
                String password = prop.getProperty("dbpassword");
                String name     = prop.getProperty("dbname");
                String url = host + name  + "?user=" + user + "&password=" + password;
                System.out.println("Conexion a la BD: " + url);


                Class.forName(driver);     // Carga el driver


                Connection con = DriverManager.getConnection(url); // Crea una conexion a la BD

                PreparedStatement ps = con.prepareStatement("SELECT * FROM VIDEOJUEGOS WHERE UPC = ?");
                ps.setString(1,upcConsulta);
                System.out.println(ps.toString());
                ps.executeQuery();
                ResultSet rs = ps.getResultSet();

                if(rs!=null && rs.next())
                {
                    String upc             = rs.getString("upc");
                    String descripcion     = rs.getString("descripcion");
                    String desarrollador   = rs.getString("desarrollador");
                    String plataforma      = rs.getString("plataforma");
                    String clasificacion   = rs.getString("clasificacion");
                    String genero          = rs.getString("genero");
                    String precio          = rs.getString("precio");
                    String imagen          = rs.getString("imagen");
                    

                    videojuego.setUpc(upc);
                    videojuego.setDescripcion(descripcion);
                    videojuego.setDesarrollador(desarrollador);
                    videojuego.setPlataforma(plataforma);
                    videojuego.setClasificacion(clasificacion);
                    videojuego.setGenero(genero);
                    videojuego.setPrecio(precio);
                    videojuego.setImagen(imagen);
                    con.close();
                    return videojuego;
                }

	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    return null;
	}
        
        // Update
        public boolean cambiar(Properties prop)
	{
            boolean exito = false;
            
            try
	    {

                String driver = prop.getProperty("dbdriver");
                String host   = prop.getProperty("dbhost");
                String user   = prop.getProperty("dbuser");
                String password = prop.getProperty("dbpassword");
                String name     = prop.getProperty("dbname");
                String url = host + name  + "?user=" + user + "&password=" + password;
                System.out.println("Conexion a la BD: " + url);


                Class.forName(driver);     // Carga el driver


                Connection con = DriverManager.getConnection(url); // Crea una conexion a la BD

                PreparedStatement ps = con.prepareStatement("UPDATE VIDEOJUEGOS SET DESCRIPCION = ?, DESARROLLADOR = ?, PLATAFORMA = ?, CLASIFICACION = ?, GENERO = ?, PRECIO = ?, IMAGEN = ? WHERE UPC = ?");
                
                ps.setString(1, this.descripcion); // El titulo que llega de la Vista
                ps.setString(2, this.desarrollador);
                ps.setString(3, this.plataforma);
                ps.setString(4, this.clasificacion);
                ps.setString(5, this.genero);
                ps.setString(6, this.precio);
                ps.setString(7, this.imagen);
                ps.setString(8, this.upc);
                System.out.println(ps.toString());
                exito = ps.executeUpdate() > 0;
                con.close();
               
	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    return exito;
	}
        
        //Delete 
        public boolean borrar(Properties prop)
	{
            boolean exito = false;
            
            try
	    {

                String driver = prop.getProperty("dbdriver");
                String host   = prop.getProperty("dbhost");
                String user   = prop.getProperty("dbuser");
                String password = prop.getProperty("dbpassword");
                String name     = prop.getProperty("dbname");
                String url = host + name  + "?user=" + user + "&password=" + password;
                System.out.println("Conexion a la BD: " + url);


                Class.forName(driver);     // Carga el driver


                Connection con = DriverManager.getConnection(url); // Crea una conexion a la BD

                PreparedStatement ps = con.prepareStatement("DELETE FROM VIDEOJUEGOS WHERE UPC = ?");
                ps.setString(1, this.upc);
                System.out.println(ps.toString());
                exito = ps.executeUpdate() > 0;
                con.close();
               
	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    return exito;
	}
        
        // Create=Insert ·
        public boolean alta(Properties prop)
	{
            boolean exito = false;
            
            try
	    {

                String driver = prop.getProperty("dbdriver");
                String host   = prop.getProperty("dbhost");
                String user   = prop.getProperty("dbuser");
                String password = prop.getProperty("dbpassword");
                String name     = prop.getProperty("dbname");
                String url = host + name  + "?user=" + user + "&password=" + password;
                System.out.println("Conexion a la BD: " + url);


                Class.forName(driver);     // Carga el driver


                Connection con = DriverManager.getConnection(url); // Crea una conexion a la BD

                PreparedStatement ps = con.prepareStatement("INSERT INTO VIDEOJUEGOS (UPC, DESCRIPCION, DESARROLLADOR, PLATAFORMA, CLASIFICACION, GENERO, PRECIO, IMAGEN) VALUES (?,?,?,?,?,?,?,?)");
                ps.setString(1, this.upc); 
                ps.setString(2, this.descripcion); 
                ps.setString(3, this.desarrollador);
                ps.setString(4, this.plataforma);
                ps.setString(5, this.clasificacion);
                ps.setString(6, this.genero);
                ps.setString(7, this.precio);
                ps.setString(8, this.imagen);
                System.out.println(ps.toString());
                exito = ps.executeUpdate() > 0;
                con.close();
               
	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    return exito;
	}
        
        
}